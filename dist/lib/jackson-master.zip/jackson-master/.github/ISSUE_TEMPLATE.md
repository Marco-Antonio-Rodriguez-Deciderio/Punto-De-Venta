This is NOT the Repo you are looking for: please DO NOT file issues unless you
have been explicitly asked to by maintainers.

Instead, you will usually want to file them either here:

* https://github.com/FasterXML/jackson-databind/issues (general Jackson databind problems)

or one of these:

* Kotlin-related: https://github.com/FasterXML/jackson-module-kotlin/issues
* Scala-releated: https://github.com/FasterXML/jackson-module-scala/issues
